/** @file
 *	@brief MAVLink comm protocol.
 *	@see http://pixhawk.ethz.ch/software/mavlink
 *	 Generated on Sunday, October 24 2010, 08:47 UTC
 */
#ifndef MAVLINK_H
#define MAVLINK_H

#include "slugs.h"

#endif
