
#include "PrivateMember.h"

using namespace SMACCM;

SMACCMPrivateMember::SMACCMPrivateMember(uint16_t foo) :
    _foo(foo)
{}

void SMACCMPrivateMember::init() {}

